UPDATE `settings` SET `message` = '7.1.1' WHERE `settings`.`type` = 'quiz_version';
CREATE TABLE `user_purchased_category` (`id` INT NOT NULL AUTO_INCREMENT , `category_id` INT NOT NULL , `user_id` INT NOT NULL , `is_Purchased` BOOLEAN NULL DEFAULT TRUE , PRIMARY KEY (`id`));
ALTER TABLE `category` ADD `plan` VARCHAR(255) NULL DEFAULT 'Free', ADD `amount` INT NULL DEFAULT 0 AFTER `plan`;

