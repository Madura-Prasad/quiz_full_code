UPDATE `settings` SET `message` = '7.0.8' WHERE `settings`.`type` = 'quiz_version';
