<?php
return array(
    'current_version'=>'7.1.1',
    'update_version'=>'7.1.2'
);
