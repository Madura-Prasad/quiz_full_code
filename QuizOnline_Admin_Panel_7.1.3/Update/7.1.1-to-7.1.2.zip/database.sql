UPDATE `settings` SET `message` = '7.1.2' WHERE `settings`.`type` = 'quiz_version';


