UPDATE `settings` SET `message` = '7.0.9' WHERE `settings`.`type` = 'quiz_version';
