<?php
return array(
    'current_version'=>'7.0.8',
    'update_version'=>'7.0.9'
);
