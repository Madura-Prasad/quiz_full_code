UPDATE `settings` SET `message` = '7.1.2' WHERE `settings`.`type` = 'quiz_version';
ALTER TABLE `tbl_learning` ADD `pdf_file` VARCHAR(255) NULL AFTER `detail`;

ALTER TABLE `category` ADD `status` BOOLEAN NOT NULL DEFAULT TRUE AFTER `amount`;


