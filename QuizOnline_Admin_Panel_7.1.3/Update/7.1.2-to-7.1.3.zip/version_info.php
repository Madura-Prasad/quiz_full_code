<?php
return array(
    'current_version'=>'7.1.2',
    'update_version'=>'7.1.3'
);
