UPDATE `settings` SET `message` = '7.0.7' WHERE `settings`.`type` = 'quiz_version';
ALTER TABLE `tbl_learning` ADD `video_id` VARCHAR(255) NOT NULL AFTER `title`;
