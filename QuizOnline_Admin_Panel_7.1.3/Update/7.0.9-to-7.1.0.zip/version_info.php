<?php
return array(
    'current_version'=>'7.0.9',
    'update_version'=>'7.1.0'
);
