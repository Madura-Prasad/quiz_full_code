UPDATE `settings` SET `message` = '7.1.0' WHERE `settings`.`type` = 'quiz_version';
